<?php

$MySQL_BaseDatos="dbcanchasonline";
$MySQL_Host="localhost:3306";
$MySQL_Usuario="root";
$MySQL_Pass="";

?>