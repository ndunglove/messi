<?php 
	setlocale(LC_TIME,"es_PE");
	date_default_timezone_set('America/Lima');
	$ruta_img="images/clubs/";
	$puntosxpartido=10;
?>
